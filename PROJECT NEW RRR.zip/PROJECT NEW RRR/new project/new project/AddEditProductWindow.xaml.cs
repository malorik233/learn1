﻿using System;
using System.Windows;

namespace new_project
{
    public partial class AddEditProductWindow : Window
    {
        private ShopDBEntities _dbContext; // Контекст базы данных
        private Product _product; // Текущий товар

        // Конструктор принимает товар и контекст базы данных
        public AddEditProductWindow(Product product, ShopDBEntities dbContext)
        {
            InitializeComponent();
            _dbContext = dbContext; // Сохраняем контекст
            _product = product; // Сохраняем товар

            // Если товар передан, заполняем поля для редактирования
            if (_product != null)
            {
                NameTextBox.Text = _product.ProductName;
                PriceTextBox.Text = _product.Price.ToString();
                DescriptionTextBox.Text = _product.Description;
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Проверка введенных данных
                if (string.IsNullOrEmpty(NameTextBox.Text))
                {
                    MessageBox.Show("Введите название товара.");
                    return;
                }

                if (!decimal.TryParse(PriceTextBox.Text, out decimal price))
                {
                    MessageBox.Show("Введите корректную цену товара.");
                    return;
                }

                // Если товар новый, создаем его
                if (_product == null)
                {
                    _product = new Product
                    {
                        ProductName = NameTextBox.Text,
                        Price = price,
                        Description = DescriptionTextBox.Text
                    };

                    _dbContext.Products.Add(_product); // Добавляем в базу данных
                }
                else
                {
                    // Если товар существует, обновляем его данные
                    _product.ProductName = NameTextBox.Text;
                    _product.Price = price;
                    _product.Description = DescriptionTextBox.Text;
                }

                _dbContext.SaveChanges(); // Сохраняем изменения
                DialogResult = true; // Закрываем окно с результатом true
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении товара: {ex.Message}");
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close(); // Закрываем окно
        }
    }
}




