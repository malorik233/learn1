﻿using System.Data.Entity;
using new_project;

public class ShopDBEntities : DbContext
{
    public ShopDBEntities() : base("name=ShopDBConnectionString") // Имя строки подключения
    {
    }

    public DbSet<Product> Products { get; set; } // Таблица продуктов
}