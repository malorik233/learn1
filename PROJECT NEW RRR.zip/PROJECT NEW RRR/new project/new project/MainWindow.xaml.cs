﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace new_project
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ShopDBEntities dbContext; // Контекст базы данных

        public MainWindow()
        {
            InitializeComponent();
            dbContext = new ShopDBEntities(); // Инициализация контекста базы данных
            LoadData(); // Вызов метода LoadData в блоке инициализации окна
        }

        private void LoadData()
        {
            try
            {
                var products = dbContext.Products.ToList(); // Получаем список продуктов из базы данных
                ProductsDataGrid.ItemsSource = products; // Устанавливаем источник данных для DataGrid
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedProduct = ProductsDataGrid.SelectedItem as Product; // Получаем выбранный товар

            if (selectedProduct == null)
            {
                MessageBox.Show("Выберите товар для редактирования.");
                return;
            }

            // Передаем выбранный товар и контекст базы данных в окно редактирования
            var editWindow = new AddEditProductWindow(selectedProduct, dbContext);
            if (editWindow.ShowDialog() == true)
            {
                LoadData(); // Обновляем данные после редактирования
            }
        }
    }
}

