﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace practiceSokolovAdminSystem
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            var loginWindow = new LoginWindow();
            bool? result = loginWindow.ShowDialog();

            if (result == true && loginWindow.AuthenticatedUser != null)
            {
                var mainWindow = new MainWindow(loginWindow.AuthenticatedUser);
                mainWindow.Show();
            }
            else
            {
                Shutdown();
            }
        }
    }

}
