﻿using practiceSokolovAdminSystem.Data;
using practiceSokolovAdminSystem.Models;
using System.Linq;
using System.Windows;

namespace practiceSokolovAdminSystem
{
    public partial class LoginWindow : Window
    {
        private readonly AppDbContext _db;

        public User? AuthenticatedUser { get; private set; }

        public LoginWindow()
        {
            InitializeComponent();
            _db = new AppDbContext();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;

            var user = _db.Users
                          .Where(u => u.Username == username && u.PassWrd == password)
                          .FirstOrDefault();

            if (user != null)
            {
                AuthenticatedUser = user;
            }
            else
            {
                ErrorText.Text = "Ошибка авторизации";
            }
        }
    }
}
