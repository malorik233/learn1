﻿using Microsoft.EntityFrameworkCore;
using practiceSokolovAdminSystem.Models;


namespace practiceSokolovAdminSystem.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Role> Roles { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Worker> Workers { get; set; }
        public DbSet<Room> Rooms { get; set; }
        public DbSet<InventoryItem> Inventory { get; set; }
        public DbSet<Record> Records { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=agafontyaDbNew;Trusted_Connection=True;");
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Role>().HasIndex(r => r.Name).IsUnique();
        }
    }
}