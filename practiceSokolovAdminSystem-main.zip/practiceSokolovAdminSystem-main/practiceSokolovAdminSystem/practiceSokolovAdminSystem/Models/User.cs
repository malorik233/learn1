﻿namespace practiceSokolovAdminSystem.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string FullName { get; set; }
        public int PassWrd { get; set; }
        public int RoleId { get; set; }
        public Role Role { get; set; }
    }
}