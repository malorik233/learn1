﻿namespace practiceSokolovAdminSystem.Models
{
    public class Room
    {
        public int Id { get; set; }
        public string Number { get; set; }
        public string Description { get; set; }
    }
}