﻿using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic;
using practiceSokolovAdminSystem.Data;
using practiceSokolovAdminSystem.Models;
using practiceSokolovAdminSystem.Services;
using System;
using System.Linq;
using System.Windows;

namespace practiceSokolovAdminSystem
{
    public partial class MainWindow : Window
    {
        private readonly User _currentUser;
        private readonly AppDbContext _db;
        private readonly Logger _logger;

        public MainWindow()
        {
            InitializeComponent();

            _db = new AppDbContext();
            _db.Database.EnsureCreated();
            SeedData();

            _currentUser = currentUser;
            _logger = new Logger(_currentUser);

            TxtRole.Text = _currentUser?.Role?.Name ?? "(роль отсутствует)";
            NavList.SelectedIndex = 0;
        }

        private void SeedData()
        {
            if (!_db.Roles.Any())
            {
                _db.Roles.AddRange(
                    new Role { Name = "Администратор системы" },
                    new Role { Name = "Технический специалист" },
                    new Role { Name = "Обслуживающий персонал" }
                );
                _db.SaveChanges();
            }

            if (!_db.Users.Any())
            {
                var role = _db.Roles.First();
                _db.Users.Add(new User
                {
                    Username = "admin",
                    FullName = "Администратор",
                    PassWrd = "123456",
                    RoleId = role.Id
                });
                _db.SaveChanges();
            }
        }

        private void NavList_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (!(NavList.SelectedItem is System.Windows.Controls.ListBoxItem sel)) return;
            string? tag = sel.Tag as string;

            switch (tag)
            {
                case "Workers": MainGrid.ItemsSource = _db.Workers.ToList(); break;
                case "Users": MainGrid.ItemsSource = _db.Users.Include(u => u.Role).ToList(); break;
                case "Rooms": MainGrid.ItemsSource = _db.Rooms.ToList(); break;
                case "Inventory": MainGrid.ItemsSource = _db.Inventory.ToList(); break;
                case "Records": MainGrid.ItemsSource = _db.Records.Include(r => r.Room).ToList(); break;
            }

            _logger.Write("Просмотр", tag);
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (!(NavList.SelectedItem is System.Windows.Controls.ListBoxItem sel)) return;
            string? tag = sel.Tag as string;

            if (tag == "Rooms")
            {
                string name = Interaction.InputBox("Введите название комнаты:", "Добавить комнату");
                if (!string.IsNullOrWhiteSpace(name))
                {
                    var room = new Room { Name = name };
                    _db.Rooms.Add(room);
                    _db.SaveChanges();
                    MainGrid.ItemsSource = _db.Rooms.ToList();
                    _logger.Write("Добавление", "Room");
                }
            }
            else
            {
                MessageBox.Show("Ошибка");
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (!(NavList.SelectedItem is System.Windows.Controls.ListBoxItem sel)) return;
            string tag = sel.Tag as string;

            if (tag == "Rooms")
            {
                if (MainGrid.SelectedItem is Room room)
                {
                    string newName = Interaction.InputBox("Введите новое название:", "Изменить комнату", room.Name);
                    if (!string.IsNullOrWhiteSpace(newName))
                    {
                        room.Name = newName;
                        _db.SaveChanges();
                        MainGrid.ItemsSource = _db.Rooms.ToList();
                        _logger.Write("Изменение", "Room");
                    }
                }
                else
                {
                    MessageBox.Show("Вы забыли выбрать комнату");
                }
            }
            else
            {
                MessageBox.Show("Ошибка");
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (!(NavList.SelectedItem is System.Windows.Controls.ListBoxItem sel)) return;
            string tag = sel.Tag as string;

            if (tag == "Rooms")
            {
                if (MainGrid.SelectedItem is Room room)
                {
                    if (MessageBox.Show("Удалить выбранную комнату?", "Удаление", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        _db.Rooms.Remove(room);
                        _db.SaveChanges();
                        MainGrid.ItemsSource = _db.Rooms.ToList();
                        _logger.Write("Удаление", "Room");
                    }
                }
                else
                {
                    MessageBox.Show("Вы забыли выбрать комнату для удаления");
                }
            }
            else
            {
                MessageBox.Show("Ошибка");
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            string query = TxtSearch.Text.ToLower();
            if (string.IsNullOrWhiteSpace(query)) return;

            var data = MainGrid.ItemsSource;
            if (data == null) return;

            var list = data.Cast<object>().Where(x => x.ToString().ToLower().Contains(query)).ToList();
            MainGrid.ItemsSource = list;
        }

        protected override void OnClosed(EventArgs e)
        {
            _db?.Dispose();
            base.OnClosed(e);
        }
    }
}