﻿using System;
using System.IO;
using practiceSokolovAdminSystem.Models;


namespace practiceSokolovAdminSystem.Services
{
    public class Logger
    {
        private readonly string _logFile;
        private readonly User _user;


        public Logger(User user)
        {
            _logFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "sochi_admin_log.txt");
            _user = user;
        }


        public void Write(string actionType, string entity)
        {
            try
            {
                var role = _user?.Role?.Name ?? "(unknown)";
                var username = _user?.Username ?? "(system)";
                var line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss}\t{role}\t{username}\t{actionType}\t{entity}" + Environment.NewLine;
                File.AppendAllText(_logFile, line);
            }
            catch { }
        }
    }
}