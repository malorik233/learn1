﻿namespace PanelAuthorizations
{
    public class User : IUser
    {
        public string Username { get; set; }
        public string Password { get; set; }

        public User(string username, string password)
        {
            Username = username;
            Password = password;
        }

        public bool СheckCorrect(string username, string password)
        {
            return Username == username && Password == password;
        }
    }
}