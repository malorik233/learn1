﻿namespace PanelAuthorizations
{
    public interface IUser
    {
        string Username { get; set; }
        string Password { get; set; }

        bool СheckCorrect(string username, string password);
    }
}