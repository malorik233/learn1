﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace PanelAuthorizations
{
    public partial class MainWindow : Window
    {
        public List<User> users;
        public List<string> loginData;
        private ShopDBEntities dbContext;

        public MainWindow()
        {
            
            InitializeComponent();
            loginData = new List<string>();

            dbContext = new ShopDBEntities();

            users = new List<User>
            {
                new User("admin", "12345678"),
                new User("guest", "12345678"),
                new User("unknown", "12345678")
            };
        }

        public void LoginEvent(object sender, RoutedEventArgs e)
        {
            string username = login_box.Text;
            string password = password_box.Text;

            var user = dbContext.Users.FirstOrDefault(u => u.Login == username && u.Password == hashedPassword);

    if (user != null && user.СheckCorrect(username, password))
            {
                DateTime loginDate = DateTime.Now;
                loginData.Add(loginDate.ToString("g"));
                ListDataAdd();
            }
        }

        public void ListDataAdd()
        {
            history_list.Items.Clear();

            foreach (var date in loginData)
            {
                history_list.Items.Add(date);
            }
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (history_list.SelectedItem != null)
            {
                string selectedItem = history_list.SelectedItem.ToString();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            LoginEvent(sender, e);
        }
    }
}