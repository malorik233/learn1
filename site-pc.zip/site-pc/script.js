// Cart functionality
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Update cart count
function updateCartCount() {
    const cartCount = document.getElementById('cart-count');
    cartCount.textContent = cart.reduce((sum, item) => sum + item.quantity, 0); // Sum quantities
}

// Add to cart from product page
document.getElementById('add-to-cart')?.addEventListener('click', () => {
    const productName = document.getElementById('product-info-name').textContent; // Используем правильный id
    const productPrice = parseFloat(document.getElementById('product-price').textContent.replace('$', ''));
    const productId = window.location.search.split('=')[1]; // Get product ID from URL

    const item = {
        id: productId,
        name: productName,
        price: productPrice,
        quantity: 1
    };

    const existingItem = cart.find(i => i.id === productId);
    if (existingItem) {
        existingItem.quantity += 1; // Increase quantity if item already exists
    } else {
        cart.push(item); // Add new item to cart
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    alert(`${productName} added to cart!`);
});

// Product data
const products = [
    {
        id: '1',
        name: 'Quantum Xtreme',
        price: 3499,
        specs: 'RTX 4090 | i9-13900K | 32GB DDR5 | 2TB NVMe',
        description: 'Quantum Xtreme — это мощный компьютер, предназначенный как для геймеров, так и для профессионалов. Благодаря передовым компонентам он обеспечивает непревзойденную производительность для игр, создания контента и многозадачности.',
        image: 'images/quantum extreme.jpg'
    },
    {
        id: '2',
        name: 'ProStudio Master',
        price: 5999,
        specs: 'RTX A6000 | Threadripper PRO | 64GB ECC | 4TB SSD',
        description: 'ProStudio Master создан для профессионалов, которым нужно лучшее. Идеально подходит для 3D-рендеринга, видеомонтажа и сложных симуляций.',
        image: 'images/prostudio.jpg'
    },
    {
        id: '3',
        name: 'Mini Nova',
        price: 1899,
        specs: 'RTX 4070 | Ryzen 7 7800X | 16GB DDR5 | 1TB SSD',
        description: 'Mini Nova — компактный, но мощный ПК, идеально подходящий для геймеров и создателей контента, которым нужна производительность в небольшом форм-факторе.',
        image: 'images/mini nova.jpg'
    },
    {
        id: '4',
        name: 'Essentials Pro',
        price: 999,
        specs: 'RTX 3060 | i5-12400F | 16GB DDR4 | 512GB SSD',
        description: 'Essentials Pro — это доступный, но производительный ПК, идеально подходящий для повседневных игр и выполнения офисных задач.',
        image: 'images/essentials pro.jpg'
    }
];

// Initialize product page
if (window.location.pathname.includes('product.html')) {
    const params = new URLSearchParams(window.location.search);
    const productId = params.get('id');

    const product = products.find(p => p.id === productId);
    if (product) {
        document.getElementById('product-hero-name').textContent = product.name; // Обновляем заголовок в hero-секции
        document.getElementById('product-info-name').textContent = product.name; // Обновляем название в info-секции
        document.getElementById('product-price').textContent = `$${product.price}`;
        document.getElementById('product-specs').textContent = product.specs;
        document.getElementById('product-description').textContent = product.description;
        document.getElementById('product-image').src = product.image;
    }
} else {
    updateCartCount();
}