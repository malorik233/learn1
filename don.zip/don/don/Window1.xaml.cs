﻿using System.Windows;

namespace don
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = usernameTextBox.Text;
            string password = passwordBox.Password;

            // Пример проверки логина и пароля
            if (username == "don" && password == "95")
            {
                // Открываем основное окно
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close(); // Закрываем окно авторизации
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль.");
            }
        
        }
    }
}